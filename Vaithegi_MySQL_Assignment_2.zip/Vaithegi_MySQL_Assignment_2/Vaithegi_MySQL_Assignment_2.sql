Create database Employee;
use Employee;
-- Department table creation.
create table Department (Department_Id int primary key, Department_Name varchar (100) not null unique);
-- Inserting values into Department table.
insert into Department values (1, 'Software Development');
insert into Department values (2, 'Marketing');
insert into Department values (3, 'Data Science');
insert into Department values (4, 'Human Resources');
insert into Department values (5, 'Product Management');
insert into Department values (6, 'Content Creation');
insert into Department values (7, 'Finance');
insert into Department values (8, 'Design');
insert into department values (9, 'Research and Development');
insert into department values (10, 'Customer Support');
insert into department values (11, 'Business Development');
insert into department values (12, 'IT');
insert into department values (13, 'Operations');
-- Location Table Creation.
Create table Location ( Location_Id int auto_increment Primary key, Location_Name varchar (50) not null unique);
-- Inserting values into Location table.
insert into Location (location_Name) values ('Chennai'),('Bangalore'),('Hyderabad');
alter table Location drop column Location_Name;
alter table Location add column Location_Name varchar (50);
insert into Location (Location_Name) values ('Chennai'), ('Bangalore'), ('Hyderabad'), ('Pune');
-- Employees table Creation.
Create table Employees (Employee_id int auto_increment primary key, 
Employee_Name varchar (50) not null, 
Gender Enum ('M', 'F') not null, 
Age int check (age>=18),
Date_Of_Join datetime default current_timestamp,
Designation varchar (100),
Department_Id int,
Location_Id int,
Salary Decimal (10,2),
Foreign key (Department_Id) references department (Department_Id),
Foreign key (Location_Id) references Location (Location_Id));
-- Inserting values into Employees table.
insert into Employees values (5001, 'Vihaan Singh', 'M', 27, '2025-01-20', 'Data Analyst', 3, 4, 60000);
insert into Employees values (5002, 'Reyansh Singh', 'M', 31, '2015-03-10', 'Network Engineer', 12, 1, 80000);
insert into employees values (5003, 'Aaradhya Iyer', 'F', 26, '2015-05-20', 'Customer Support Executive', 10, 2, 45000);
insert into employees values (5004, 'Kiara Malhotra', 'F', 29, '2015-07-05', NULL, 8, 3, 70000); 
insert into employees values (5005, 'Anvi Chaudhary', 'F', 25, '2015-09-11', 'Business Development Executive', 11, 1, 55000);
insert into employees values (5006, 'Dhruv Shetty', 'M', 28, '2015-11-20', 'UI Developer', 8, 2, 65000);
insert into employees values (5007, 'Anushka Singh', 'F', 32, '2016-01-15', 'Marketing Manager', 2, 3, 90000),
(5008, 'Diya Jha', 'F', 27, '2016-03-05', 'Graphic Designer', 8, 4, 70000),
(5009, 'Kiaan Desai', 'M', 30, '2016-05-20', 'Sales Executive', 11, 3, 55000),
(5010, 'Atharv Yadav', 'M', 29, '2016-07-10', 'Systems Administrator', 12, 4, 80000),
(5011, 'Saanvi Patel', 'F', 28, '2016-09-20', 'Marketing Analyst', 2, 1, 60000),
(5012, 'Myra Verma', 'F', 26, '2016-11-05', 'Operations Manager', 13, 2, 95000),
(5013, 'Arnav Rao', 'M', 33, '2017-01-20', 'Customer Success Manager', 10, 3, 75000),
(5014, 'Vihaan Mohan', 'M', 30, '2017-03-10', 'Supply Chain Analyst', 10, 2, 60000),
(5015, 'Ishaan Kumar', 'M', 27, '2017-05-20', 'Financial Analyst', 7, 1, 85000),
(5016, 'Zoya Khan', 'F', 31, '2017-07-05', 'Legal Counsel', 4, 4, 100000),
(5017, 'Kabir Nair', 'M', 28, '2017-09-11', 'IT Support Specialist', 12, 2, 80000),
(5018, 'Ishan Mishra', 'M', 25, '2017-11-20', 'Research Scientist', 9, 3, 75000),
(5019, 'Ishika Patel', 'F', 29, '2018-01-15', 'Talent Acquisition Specialist', 4, 4, 55000),
(5020, 'Aarav Nair', 'M', 32, '2018-03-05', 'Software Engineer', 1, 1, 90000),
(5021, 'Advik Kapoor', 'M', 26, '2018-05-20', 'Finance Analyst', 7, 3, 85000),
(5022, 'Aadhya Iyengar', 'F', 28, '2018-07-10', 'HR Specialist', 4, 4, 60000),
(5023, 'Anika Paul', 'F', 30, '2018-09-20', 'Public Relations Specialist', 2, 2, 70000),
(5024, 'Aryan Shetty', 'M', 27, '2018-11-05', 'Product Manager', 5, 1, 95000),
(5025, 'Avni Iyengar', 'F', 31, '2019-01-20', 'Data Scientist', 3, 4, 100000),
(5026, 'Vivaan Singh', 'M', 29, '2019-03-10', 'Business Analyst', 3, 2, 75000),
(5027, 'Ananya Paul', 'F', 32, '2019-05-20', 'Content Writer', 6, 3, 60000),
(5028, 'Anaya Kapoor', 'F', 26, '2019-07-05', 'Event Coordinator', 6, 1, 60000),
(5029, 'Arjun Kumar', 'M', 33, '2019-09-11', 'Quality Assurance Analyst', 12, 2, 80000),
(5030, 'Sara Iyer', 'F', 28, '2019-11-20', 'Project Manager', 5, 1, 90000);
select * from Department;
select * from location;
Drop table location;
Delete from location where location_id in (1,2,3);
alter table location drop column location_id;
select * from employees;
update location set Location_Id = 1 where Location_Id = 4;
UPDATE employees SET Location_Id = 1 WHERE Location_Id = 4;
UPDATE employees SET Location_Id = 2 WHERE Location_Id = 5;
UPDATE employees SET Location_Id = 3 WHERE Location_Id = 6;
UPDATE employees SET Location_Id = 4 WHERE Location_Id = 7;
update location set Location_Id = 2 where Location_Id = 5;
ALTER TABLE location AUTO_INCREMENT = 1;
select * from location;
alter table location drop column location_name;
ALTER TABLE location ADD COLUMN Location_Name VARCHAR(50) NOT NULL;
UPDATE location SET Location_Name = 'Chennai'   WHERE Location_Id = 1;
UPDATE location SET Location_Name = 'Bangalore' WHERE Location_Id = 2;
UPDATE location SET Location_Name = 'Hyderabad' WHERE Location_Id = 3;
UPDATE location SET Location_Name = 'Pune'      WHERE Location_Id = 4;
select * from location;
Select distinct salary from employees;
Select Age as Employee_Age, Salary as Employee_Salary from Employees;
Select * from Employees where Salary > 50000 and Date_Of_Join < '2016-01-01';
update employees set Date_Of_Join = '2015-01-20' where Employee_Id = 5001;
update employees set Designation = 'Data Scientist' where Designation is NULL;
use Employee;
select * from Employees order by Department_Id ASC , salary Desc ;
select * from Employees where year (Date_Of_Join) = 2018 order by Date_Of_Join Asc limit 5; 
SELECT SUM(e.Salary) AS Total_Salary
FROM Employees e
JOIN Department d 
  ON e.Department_Id = d.Department_Id
WHERE d.Department_Name = 'Finance';
select min(age) as Minimum_Age from employees;
select L.Location_name, max(e.salary) as max_salary 
from employees e join Location L on E.Location_Id = L.Location_Id group by L.Location_Name;
select Designation, avg(salary) as Avg_Salary 
from employees where Designation like '%Analyst%' group by Designation;
select D.Department_Name, count(e.Employee_Id) as Emp_Count 
from Employees e join department d on e.department_id = d.department_id 
group by d.department_name having count(e.Employee_Id)<3;
Select L.Location_Name, avg(e.age) as Avg_Age
From Employees e Join Location L on E.Location_Id = L.Location_Id 
Where E.Gender = 'F' group by L.Location_Name having Avg(E.Age)<30;
Select E.Employee_Name, E.Designation, D.Department_Name from Employees e 
inner join Department d on E.Department_id = D.Department_id;
select D.Department_Name, count(E.Employee_Id) as Employee_Count
from Department d left Join Employees e on d.department_id = e.department_id
group by d.department_name;
Select L.Location_name, e.Employee_Name from Employees e
Right join Location L on E.Location_id = L.Location_id;